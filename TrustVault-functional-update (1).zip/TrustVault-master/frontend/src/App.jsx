import { useEffect, useState } from 'react'
import { apiRequest, login, register } from './api'
import './App.css'

const roles = [
  { id: 'admin', title: 'Administrator', icon: '🛡️', description: 'Manage documents, users, and audit activity.' },
  { id: 'owner', title: 'Document Owner', icon: '📁', description: 'Upload documents and manage access to your files.' },
  { id: 'viewer', title: 'Viewer', icon: '👁️', description: 'Access documents shared with your account.' },
]

function App() {
  const [selectedRole, setSelectedRole] = useState(null)
  const [mode, setMode] = useState('login')
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [session, setSession] = useState(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(false)
  const [documents, setDocuments] = useState([])
  const [auditLogs, setAuditLogs] = useState([])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [uploadName, setUploadName] = useState('')
  const [uploadCategory, setUploadCategory] = useState('')
  const [uploadFile, setUploadFile] = useState(null)
  const [editId, setEditId] = useState(null)
  const [editName, setEditName] = useState('')
  const [editCategory, setEditCategory] = useState('')
  const [permissionDocId, setPermissionDocId] = useState('')
  const [permissionUsername, setPermissionUsername] = useState('')
  const [permissionLevel, setPermissionLevel] = useState('read')
  const [revokeDocId, setRevokeDocId] = useState('')
  const [revokeUsername, setRevokeUsername] = useState('')
  const [targetUsername, setTargetUsername] = useState('')
  const [targetRole, setTargetRole] = useState('owner')

  const token = session?.token
  const actualRole = session?.user?.role

  async function loadWorkspace(current = session) {
    if (!current?.token) return
    setError('')
    try {
      const [user, docs] = await Promise.all([
        apiRequest('/me', {}, current.token),
        apiRequest(actualRole === 'admin' ? `/admin/documents?search=${encodeURIComponent(search)}&category=${encodeURIComponent(category)}` : '/documents', {}, current.token),
      ])
      setSession({ ...current, user })
      setDocuments(docs)
      if (user.role === 'admin') {
        const logs = await apiRequest('/admin/audit-logs?limit=100', {}, current.token)
        setAuditLogs(logs)
      } else {
        setAuditLogs([])
      }
    } catch (err) {
      setError(err.message || 'Unable to load your workspace.')
    }
  }

  useEffect(() => {
    if (session?.token) loadWorkspace(session)
    // Search filters are applied when the user presses Search/Refresh.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.token])

  async function handleLogin(event) {
    event.preventDefault()
    setError(''); setNotice(''); setLoading(true)
    try {
      const result = await login(username.trim(), password)
      const user = await apiRequest('/me', {}, result.access_token)
      if (selectedRole && user.role !== selectedRole.id) {
        throw new Error(`This account is a ${user.role} account. Please choose the matching workspace.`)
      }
      setSession({ token: result.access_token, user })
      setPassword('')
    } catch (err) {
      setError(err.message || 'Sign in failed. Check your credentials and API configuration.')
    } finally { setLoading(false) }
  }

  async function handleRegister(event) {
    event.preventDefault()
    setError(''); setNotice(''); setLoading(true)
    try {
      await register(username.trim(), email.trim(), password)
      setNotice('Account created as a Viewer. Sign in now. An administrator can promote trusted users to Document Owner or Administrator.')
      setMode('login')
      setPassword('')
    } catch (err) {
      setError(err.message || 'Registration failed.')
    } finally { setLoading(false) }
  }

  function signOut() {
    setSession(null); setSelectedRole(null); setMode('login')
    setUsername(''); setEmail(''); setPassword('')
    setDocuments([]); setAuditLogs([]); setError(''); setNotice('')
  }

  async function refresh() { await loadWorkspace(session) }

  async function handleUpload(event) {
    event.preventDefault(); setError(''); setNotice('')
    if (!uploadFile) { setError('Choose a file first.'); return }
    const body = new FormData()
    body.append('name', uploadName.trim())
    body.append('category', uploadCategory.trim())
    body.append('file', uploadFile)
    setLoading(true)
    try {
      await apiRequest('/documents/upload', { method: 'POST', body }, token)
      setUploadName(''); setUploadCategory(''); setUploadFile(null)
      event.currentTarget.reset()
      setNotice('Document uploaded successfully.')
      await refresh()
    } catch (err) { setError(err.message) } finally { setLoading(false) }
  }

  async function downloadDocument(doc) {
    setError(''); setNotice('')
    try {
      const response = await fetch(`${(import.meta.env.VITE_API_BASE_URL || '').replace(/\/+$/, '')}/documents/${doc.id}/download`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (!response.ok) {
        const data = await response.json().catch(() => ({}))
        throw new Error(data.detail || `Download failed (${response.status})`)
      }
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = url; anchor.download = doc.name || `document-${doc.id}`
      document.body.appendChild(anchor); anchor.click(); anchor.remove()
      URL.revokeObjectURL(url)
      setNotice(`Downloaded "${doc.name}".`)
    } catch (err) { setError(err.message || 'Download failed.') }
  }

  async function deleteDocument(doc) {
    if (!window.confirm(`Delete "${doc.name}" permanently?`)) return
    setError(''); setNotice('')
    try {
      await apiRequest(`/documents/${doc.id}`, { method: 'DELETE' }, token)
      setNotice('Document deleted.')
      await refresh()
    } catch (err) { setError(err.message) }
  }

  async function saveEdit(event) {
    event.preventDefault(); setError(''); setNotice('')
    try {
      await apiRequest(`/documents/${editId}`, {
        method: 'PUT',
        body: JSON.stringify({ name: editName.trim(), category: editCategory.trim() }),
      }, token)
      setEditId(null); setNotice('Document details updated.')
      await refresh()
    } catch (err) { setError(err.message) }
  }

  async function grantPermission(event) {
    event.preventDefault(); setError(''); setNotice('')
    try {
      await apiRequest(`/documents/${permissionDocId}/permissions`, {
        method: 'POST',
        body: JSON.stringify({ username: permissionUsername.trim(), access_level: permissionLevel }),
      }, token)
      setNotice(`Granted ${permissionLevel} access to ${permissionUsername}.`)
      setPermissionUsername('')
    } catch (err) { setError(err.message) }
  }

  async function revokePermission(event) {
    event.preventDefault(); setError(''); setNotice('')
    try {
      await apiRequest(`/documents/${revokeDocId}/permissions/${encodeURIComponent(revokeUsername.trim())}`, { method: 'DELETE' }, token)
      setNotice(`Access revoked for ${revokeUsername}.`)
      setRevokeUsername('')
    } catch (err) { setError(err.message) }
  }

  async function changeRole(event) {
    event.preventDefault(); setError(''); setNotice('')
    try {
      const result = await apiRequest('/admin/users/role', {
        method: 'POST',
        body: JSON.stringify({ username: targetUsername.trim(), role: targetRole }),
      }, token)
      setNotice(`Role updated to ${result.role} for ${targetUsername}.`)
      setTargetUsername('')
    } catch (err) { setError(err.message) }
  }

  async function searchAdmin(event) {
    event.preventDefault(); setError('')
    try {
      const docs = await apiRequest(`/admin/documents?search=${encodeURIComponent(search)}&category=${encodeURIComponent(category)}`, {}, token)
      setDocuments(docs)
    } catch (err) { setError(err.message) }
  }

  return (
    <main className="app">
      <header className="topbar">
        <a className="brand" href="#" onClick={(e) => { e.preventDefault(); signOut() }}>
          <span className="brand-icon">T</span><span>TrustVault</span>
        </a>
        <span className="security-label"><span className="status-dot" /> Secure Document Management</span>
      </header>

      {!session ? (
        !selectedRole ? (
          <section className="role-screen">
            <div className="eyebrow">YOUR DOCUMENTS. YOUR CONTROL.</div>
            <h1>Welcome to TrustVault</h1>
            <p className="subtitle">Choose your workspace, then sign in. New accounts begin as Viewers.</p>
            <div className="role-list">
              {roles.map((role) => <button key={role.id} className="role-card" onClick={() => { setSelectedRole(role); setError(''); setNotice(''); setMode('login') }}>
                <span className="role-icon">{role.icon}</span>
                <span className="role-copy"><strong>{role.title}</strong><span>{role.description}</span></span>
                <span className="role-arrow">→</span>
              </button>)}
            </div>
            <p className="footnote">Selecting a workspace never grants permissions. The server checks your actual account role.</p>
            <p className="footnote">API URL: {import.meta.env.VITE_API_BASE_URL || 'not configured (same-origin)'}</p>
          </section>
        ) : (
          <section className="auth-panel">
            <button className="back-button" onClick={() => { setSelectedRole(null); setError(''); setNotice('') }}>← Back to roles</button>
            <div className="dashboard-icon">{selectedRole.icon}</div>
            <div className="eyebrow">TRUSTVAULT SECURE ACCESS</div>
            <h1>{mode === 'login' ? selectedRole.title : 'Create an account'}</h1>
            <div className="auth-tabs">
              <button className={mode === 'login' ? 'active' : ''} onClick={() => { setMode('login'); setError(''); setNotice('') }}>Sign in</button>
              <button className={mode === 'register' ? 'active' : ''} onClick={() => { setMode('register'); setError(''); setNotice('') }}>Create account</button>
            </div>
            <form className="login-form" onSubmit={mode === 'login' ? handleLogin : handleRegister}>
              <label htmlFor="username">Username</label>
              <input id="username" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} minLength={3} maxLength={50} required />
              {mode === 'register' && <>
                <label htmlFor="email">Email</label>
                <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </>}
              <label htmlFor="password">Password {mode === 'register' && '(at least 12 characters)'}</label>
              <input id="password" type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} minLength={mode === 'register' ? 12 : 1} required />
              {error && <p className="error-message" role="alert">{error}</p>}
              {notice && <p className="success-message" role="status">{notice}</p>}
              <button className="primary-button" type="submit" disabled={loading}>{loading ? 'Please wait…' : mode === 'login' ? 'Sign in securely' : 'Create account'}</button>
            </form>
          </section>
        )
      ) : (
        <section className="workspace">
          <div className="workspace-heading">
            <div>
              <div className="eyebrow">AUTHENTICATED WORKSPACE</div>
              <h1>Welcome, {session.user.username}</h1>
              <p className="subtitle">Role: <strong>{session.user.role}</strong> · Only server-authorized actions will succeed.</p>
            </div>
            <button className="back-button" onClick={signOut}>Sign out</button>
          </div>
          {error && <p className="error-message" role="alert">{error}</p>}
          {notice && <p className="success-message" role="status">{notice}</p>}
          <div className="toolbar">
            <button className="primary-button" onClick={refresh}>Refresh workspace</button>
          </div>

          {(actualRole === 'owner' || actualRole === 'admin') && <section className="panel">
            <h2>Upload a document</h2>
            <form className="action-form" onSubmit={handleUpload}>
              <label>Document name<input value={uploadName} onChange={(e) => setUploadName(e.target.value)} required maxLength={255} /></label>
              <label>Category<input value={uploadCategory} onChange={(e) => setUploadCategory(e.target.value)} required maxLength={100} /></label>
              <label>Choose file (max 10 MB)<input type="file" onChange={(e) => setUploadFile(e.target.files?.[0] || null)} required /></label>
              <button className="primary-button" disabled={loading}>Upload document</button>
            </form>
          </section>}

          {actualRole === 'admin' && <section className="panel">
            <h2>Administrator: search documents</h2>
            <form className="action-form search-form" onSubmit={searchAdmin}>
              <label>Name contains<input value={search} onChange={(e) => setSearch(e.target.value)} /></label>
              <label>Exact category<input value={category} onChange={(e) => setCategory(e.target.value)} /></label>
              <button className="primary-button">Search</button>
            </form>
          </section>}

          <section className="panel">
            <div className="panel-title"><h2>{actualRole === 'admin' ? 'All documents' : 'Documents you can access'}</h2><span>{documents.length} item(s)</span></div>
            {documents.length === 0 ? <p className="empty-state">No documents available for this account yet.</p> : <div className="table-wrap"><table>
              <thead><tr><th>Name</th><th>Category</th><th>Owner ID</th><th>Created</th><th>Actions</th></tr></thead>
              <tbody>{documents.map((doc) => <tr key={doc.id}>
                <td>{doc.name}</td><td>{doc.category}</td><td>{doc.owner_id}</td><td>{doc.created_at ? new Date(doc.created_at).toLocaleString() : '—'}</td>
                <td className="row-actions">
                  <button onClick={() => downloadDocument(doc)}>Download</button>
                  {(actualRole === 'admin' || doc.owner_id === session.user.id) && <>
                    <button onClick={() => { setEditId(doc.id); setEditName(doc.name); setEditCategory(doc.category) }}>Edit</button>
                    <button className="danger-button" onClick={() => deleteDocument(doc)}>Delete</button>
                  </>}
                  {(actualRole === 'admin' || doc.owner_id === session.user.id) && <button onClick={() => { setPermissionDocId(String(doc.id)); setRevokeDocId(String(doc.id)) }}>Manage access</button>}
                </td>
              </tr>)}</tbody>
            </table></div>}
          </section>

          {editId !== null && <section className="panel">
            <h2>Edit document #{editId}</h2>
            <form className="action-form" onSubmit={saveEdit}>
              <label>Name<input value={editName} onChange={(e) => setEditName(e.target.value)} required /></label>
              <label>Category<input value={editCategory} onChange={(e) => setEditCategory(e.target.value)} required /></label>
              <button className="primary-button">Save changes</button><button type="button" onClick={() => setEditId(null)}>Cancel</button>
            </form>
          </section>}

          {(actualRole === 'owner' || actualRole === 'admin') && <section className="panel">
            <h2>Grant document access</h2>
            <form className="action-form" onSubmit={grantPermission}>
              <label>Document ID<input type="number" min="1" value={permissionDocId} onChange={(e) => setPermissionDocId(e.target.value)} required /></label>
              <label>Username<input value={permissionUsername} onChange={(e) => setPermissionUsername(e.target.value)} required /></label>
              <label>Access level<select value={permissionLevel} onChange={(e) => setPermissionLevel(e.target.value)}><option value="read">Read</option><option value="edit">Edit</option></select></label>
              <button className="primary-button">Grant access</button>
            </form>
            <h2 className="subheading">Revoke access</h2>
            <form className="action-form" onSubmit={revokePermission}>
              <label>Document ID<input type="number" min="1" value={revokeDocId} onChange={(e) => setRevokeDocId(e.target.value)} required /></label>
              <label>Username<input value={revokeUsername} onChange={(e) => setRevokeUsername(e.target.value)} required /></label>
              <button className="danger-button">Revoke access</button>
            </form>
          </section>}

          {actualRole === 'admin' && <section className="panel">
            <h2>Change a user's role</h2>
            <p className="muted">New registrations are Viewers. Promote only trusted accounts.</p>
            <form className="action-form" onSubmit={changeRole}>
              <label>Username<input value={targetUsername} onChange={(e) => setTargetUsername(e.target.value)} required /></label>
              <label>New role<select value={targetRole} onChange={(e) => setTargetRole(e.target.value)}><option value="viewer">Viewer</option><option value="owner">Document Owner</option><option value="admin">Administrator</option></select></label>
              <button className="primary-button">Update role</button>
            </form>
          </section>}

          {actualRole === 'admin' && <section className="panel">
            <div className="panel-title"><h2>Recent audit activity</h2><span>Latest {auditLogs.length}</span></div>
            {auditLogs.length === 0 ? <p className="empty-state">No audit events recorded yet.</p> : <div className="table-wrap"><table>
              <thead><tr><th>Time</th><th>User ID</th><th>Action</th><th>Document ID</th><th>Details</th></tr></thead>
              <tbody>{auditLogs.map((log) => <tr key={log.id}><td>{log.created_at ? new Date(log.created_at).toLocaleString() : '—'}</td><td>{log.user_id ?? '—'}</td><td>{log.action}</td><td>{log.document_id ?? '—'}</td><td>{log.details}</td></tr>)}</tbody>
            </table></div>}
          </section>}
        </section>
      )}
      <footer><span>TrustVault</span><span>Confidential documents, protected access.</span></footer>
    </main>
  )
}
export default App
