# TrustVault frontend deployment

The frontend must call your deployed FastAPI backend, not `http://localhost:8000`.

In Render, open the **trustvault-frontend** Static Site → **Environment** and add:

- Key: `VITE_API_BASE_URL`
- Value: the public HTTPS URL of your deployed TrustVault backend, with no trailing slash (example format: `https://your-backend-service.onrender.com`).

Save changes and trigger a new deploy. Vite reads `VITE_` variables at build time, so changing the variable requires rebuilding/redeploying the frontend.

Then verify:
1. Open `https://YOUR-BACKEND-URL/health` and confirm it returns `{"status":"running"}`.
2. Open the frontend and try registering a new account. New accounts are Viewer by default.
3. Sign in and confirm the workspace loads. The `/me` endpoint returns the current server-side role.
4. Promote a trusted account to owner/admin using an existing admin account before testing those actions.

Do not place database URLs, `TRUSTVAULT_SECRET_KEY`, admin passwords, or other secrets in frontend variables. Only the public backend URL belongs in `VITE_API_BASE_URL`.
